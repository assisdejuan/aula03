Segue imagens do projeto em execução:



![90b085e1-6101-46ee-b287-31f1d6f5bb76](https://github.com/user-attachments/assets/9a12e897-f7f3-45e7-9472-6c4b086747b0)
![52afef32-f84f-4847-8b21-8653c245efc1](https://github.com/user-attachments/assets/c0fdd066-1fc9-4d96-93ca-e59ee6769a74)
