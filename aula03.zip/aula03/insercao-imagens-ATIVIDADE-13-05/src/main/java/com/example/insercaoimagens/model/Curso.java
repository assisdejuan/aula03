package com.example.insercaoimagens.model;

public enum Curso {
    ADS, ECMP, CCMP, OUTROS
}
